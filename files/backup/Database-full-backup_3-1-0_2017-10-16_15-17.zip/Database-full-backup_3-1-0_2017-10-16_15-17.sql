#
# TABLE STRUCTURE FOR: article_has_attachments
#

DROP TABLE IF EXISTS article_has_attachments;

CREATE TABLE `article_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `article_id` bigint(20) DEFAULT '0',
  `filename` varchar(250) DEFAULT '0',
  `savename` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS clients;

CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(140) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `email` varchar(180) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) NOT NULL,
  `userpic` varchar(150) NOT NULL DEFAULT 'no-pic.png',
  `city` varchar(45) DEFAULT NULL,
  `hashed_password` varchar(255) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `access` varchar(150) DEFAULT '0',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  `twitter` varchar(255) NOT NULL DEFAULT '',
  `skype` varchar(255) NOT NULL DEFAULT '',
  `linkedin` varchar(255) NOT NULL DEFAULT '',
  `facebook` varchar(255) NOT NULL DEFAULT '',
  `instagram` varchar(255) NOT NULL DEFAULT '',
  `googleplus` varchar(255) NOT NULL DEFAULT '',
  `youtube` varchar(255) NOT NULL DEFAULT '',
  `pinterest` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: companies
#

DROP TABLE IF EXISTS companies;

CREATE TABLE `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) NOT NULL,
  `name` varchar(140) DEFAULT NULL,
  `client_id` varchar(140) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) NOT NULL,
  `city` varchar(45) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `website` varchar(250) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `vat` varchar(250) DEFAULT NULL,
  `note` longtext,
  `province` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) NOT NULL DEFAULT '',
  `skype` varchar(255) NOT NULL DEFAULT '',
  `linkedin` varchar(255) NOT NULL DEFAULT '',
  `facebook` varchar(255) NOT NULL DEFAULT '',
  `instagram` varchar(255) NOT NULL DEFAULT '',
  `googleplus` varchar(255) NOT NULL DEFAULT '',
  `youtube` varchar(255) NOT NULL DEFAULT '',
  `pinterest` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: company_has_admins
#

DROP TABLE IF EXISTS company_has_admins;

CREATE TABLE `company_has_admins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `company_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `access` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: core
#

DROP TABLE IF EXISTS core;

CREATE TABLE `core` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` char(10) NOT NULL DEFAULT '0',
  `domain` varchar(65) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `tax` varchar(5) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `autobackup` int(11) DEFAULT NULL,
  `cronjob` int(11) DEFAULT NULL,
  `last_cronjob` int(11) DEFAULT NULL,
  `last_autobackup` int(11) DEFAULT NULL,
  `invoice_terms` mediumtext,
  `company_reference` int(6) DEFAULT NULL,
  `project_reference` int(6) DEFAULT NULL,
  `invoice_reference` int(6) DEFAULT NULL,
  `subscription_reference` int(6) DEFAULT NULL,
  `ticket_reference` int(10) DEFAULT NULL,
  `date_format` varchar(20) DEFAULT NULL,
  `date_time_format` varchar(20) DEFAULT NULL,
  `invoice_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_link_mail_subject` varchar(150) DEFAULT NULL,
  `credentials_mail_subject` varchar(150) DEFAULT NULL,
  `notification_mail_subject` varchar(150) DEFAULT NULL,
  `language` varchar(150) DEFAULT NULL,
  `invoice_address` varchar(200) DEFAULT NULL,
  `invoice_city` varchar(200) DEFAULT NULL,
  `invoice_contact` varchar(200) DEFAULT NULL,
  `invoice_tel` varchar(50) DEFAULT NULL,
  `subscription_mail_subject` varchar(250) DEFAULT NULL,
  `logo` varchar(150) DEFAULT NULL,
  `template` varchar(200) DEFAULT 'blueline',
  `paypal` varchar(5) DEFAULT '1',
  `paypal_currency` varchar(200) DEFAULT 'EUR',
  `paypal_account` varchar(200) DEFAULT '',
  `invoice_logo` varchar(150) DEFAULT 'assets/blueline/img/invoice_logo.png',
  `pc` varchar(150) DEFAULT NULL,
  `vat` varchar(150) DEFAULT NULL,
  `ticket_email` varchar(250) DEFAULT NULL,
  `ticket_default_owner` int(10) DEFAULT '1',
  `ticket_default_queue` int(10) DEFAULT '1',
  `ticket_default_type` int(10) DEFAULT '1',
  `ticket_default_status` varchar(200) DEFAULT 'new',
  `ticket_config_host` varchar(250) DEFAULT NULL,
  `ticket_config_login` varchar(250) DEFAULT NULL,
  `ticket_config_pass` varchar(250) DEFAULT NULL,
  `ticket_config_port` varchar(250) DEFAULT NULL,
  `ticket_config_ssl` varchar(250) DEFAULT NULL,
  `ticket_config_email` varchar(250) DEFAULT NULL,
  `ticket_config_flags` varchar(250) DEFAULT '/notls',
  `ticket_config_search` varchar(250) DEFAULT 'UNSEEN',
  `ticket_config_timestamp` int(11) DEFAULT '0',
  `ticket_config_mailbox` varchar(250) DEFAULT NULL,
  `ticket_config_delete` int(11) DEFAULT '0',
  `ticket_config_active` int(11) DEFAULT '0',
  `ticket_config_imap` int(11) DEFAULT '1',
  `stripe` int(11) DEFAULT '0',
  `stripe_key` varchar(250) DEFAULT NULL,
  `stripe_p_key` varchar(255) DEFAULT '',
  `stripe_currency` varchar(255) DEFAULT 'USD',
  `bank_transfer` int(11) DEFAULT '0',
  `bank_transfer_text` longtext,
  `estimate_terms` longtext,
  `estimate_prefix` varchar(250) DEFAULT 'EST',
  `estimate_pdf_template` varchar(250) DEFAULT 'templates/estimate/blueline',
  `invoice_pdf_template` varchar(250) DEFAULT 'templates/invoice/blueline',
  `second_tax` varchar(5) DEFAULT '',
  `estimate_mail_subject` varchar(255) DEFAULT 'New Estimate #{estimate_id}',
  `money_format` int(20) unsigned NOT NULL DEFAULT '1',
  `money_currency_position` int(20) unsigned NOT NULL DEFAULT '1',
  `pdf_font` varchar(255) DEFAULT 'NotoSans',
  `pdf_path` int(10) unsigned NOT NULL DEFAULT '1',
  `registration` int(10) unsigned NOT NULL DEFAULT '0',
  `authorize_api_login_id` varchar(255) DEFAULT NULL,
  `authorize_api_transaction_key` varchar(255) DEFAULT NULL,
  `authorize_net` int(20) DEFAULT NULL,
  `authorize_currency` varchar(30) DEFAULT NULL,
  `invoice_prefix` varchar(255) NOT NULL DEFAULT '',
  `company_prefix` varchar(255) NOT NULL DEFAULT '',
  `quotation_prefix` varchar(255) NOT NULL DEFAULT '',
  `project_prefix` varchar(255) NOT NULL DEFAULT '',
  `subscription_prefix` varchar(255) NOT NULL DEFAULT '',
  `calendar_google_api_key` varchar(255) DEFAULT NULL,
  `calendar_google_event_address` varchar(255) DEFAULT NULL,
  `default_client_modules` varchar(255) DEFAULT NULL,
  `estimate_reference` int(10) NOT NULL,
  `login_background` varchar(255) DEFAULT 'field.jpg',
  `custom_colors` int(1) DEFAULT '1',
  `top_bar_background` varchar(60) DEFAULT '#FFFFFF',
  `top_bar_color` varchar(60) DEFAULT '#333333',
  `body_background` varchar(60) DEFAULT '#D8DCE3',
  `menu_background` varchar(60) DEFAULT '#2c3e4d',
  `menu_color` varchar(60) DEFAULT '#FFFFFF',
  `primary_color` varchar(60) DEFAULT '#28a9f1',
  `twocheckout_seller_id` varchar(250) DEFAULT '',
  `twocheckout_publishable_key` varchar(250) DEFAULT '',
  `twocheckout_private_key` varchar(250) DEFAULT '',
  `twocheckout` int(11) DEFAULT '0',
  `twocheckout_currency` varchar(250) DEFAULT '',
  `login_logo` varchar(255) DEFAULT '',
  `login_style` varchar(255) DEFAULT 'left',
  `reference_lenght` int(11) DEFAULT '0',
  `stripe_ideal` int(1) unsigned NOT NULL DEFAULT '0',
  `zip_position` varchar(10) DEFAULT 'left',
  `timezone` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO core (`id`, `version`, `domain`, `email`, `company`, `tax`, `currency`, `autobackup`, `cronjob`, `last_cronjob`, `last_autobackup`, `invoice_terms`, `company_reference`, `project_reference`, `invoice_reference`, `subscription_reference`, `ticket_reference`, `date_format`, `date_time_format`, `invoice_mail_subject`, `pw_reset_mail_subject`, `pw_reset_link_mail_subject`, `credentials_mail_subject`, `notification_mail_subject`, `language`, `invoice_address`, `invoice_city`, `invoice_contact`, `invoice_tel`, `subscription_mail_subject`, `logo`, `template`, `paypal`, `paypal_currency`, `paypal_account`, `invoice_logo`, `pc`, `vat`, `ticket_email`, `ticket_default_owner`, `ticket_default_queue`, `ticket_default_type`, `ticket_default_status`, `ticket_config_host`, `ticket_config_login`, `ticket_config_pass`, `ticket_config_port`, `ticket_config_ssl`, `ticket_config_email`, `ticket_config_flags`, `ticket_config_search`, `ticket_config_timestamp`, `ticket_config_mailbox`, `ticket_config_delete`, `ticket_config_active`, `ticket_config_imap`, `stripe`, `stripe_key`, `stripe_p_key`, `stripe_currency`, `bank_transfer`, `bank_transfer_text`, `estimate_terms`, `estimate_prefix`, `estimate_pdf_template`, `invoice_pdf_template`, `second_tax`, `estimate_mail_subject`, `money_format`, `money_currency_position`, `pdf_font`, `pdf_path`, `registration`, `authorize_api_login_id`, `authorize_api_transaction_key`, `authorize_net`, `authorize_currency`, `invoice_prefix`, `company_prefix`, `quotation_prefix`, `project_prefix`, `subscription_prefix`, `calendar_google_api_key`, `calendar_google_event_address`, `default_client_modules`, `estimate_reference`, `login_background`, `custom_colors`, `top_bar_background`, `top_bar_color`, `body_background`, `menu_background`, `menu_color`, `primary_color`, `twocheckout_seller_id`, `twocheckout_publishable_key`, `twocheckout_private_key`, `twocheckout`, `twocheckout_currency`, `login_logo`, `login_style`, `reference_lenght`, `stripe_ideal`, `zip_position`, `timezone`) VALUES ('1', '3.1.0', 'https://cockpit-bogorista.c9users.io', 'hello@bogordesain.com', 'Bogor Desain', '0', 'Rp', '1', '1', '0', '0', 'Thank you for your business. We do expect payment within {due_date}, so please process this invoice within that time.', '41001', '51001', '31001', '61001', '10000', 'Y/m/d', 'g:i A', 'New Invoice', 'Password Reset', 'Password Reset', 'Login Details', 'Notification', 'english', 'Jl Cimanggu Kecil RT 02 RW 07, Ciwaringin', 'Bogor Tengah', 'Iman Sugirman', '0811800364', 'New Subscription', 'assets/blueline/images/FC2_logo_light.png', 'blueline', '0', 'USD', '', 'assets/blueline/images/FC2_logo_dark.png', 'ce3beba8-4f42-4e9a-81a0-da7f6e1144be', NULL, NULL, '1', '1', '1', 'new', NULL, NULL, NULL, NULL, NULL, NULL, '/notls', 'UNSEEN', '0', NULL, '0', '0', '1', '0', NULL, '', 'USD', '0', NULL, NULL, 'EST', 'templates/estimate/blueline', 'templates/invoice/blueline', '', 'New Estimate #{estimate_id}', '1', '1', 'NotoSans', '1', '0', NULL, NULL, NULL, NULL, '', '', '', '', '', NULL, NULL, NULL, '20000', 'field.jpg', '1', '#FFFFFF', '#333333', '#D8DCE3', '#2c3e4d', '#FFFFFF', '#28a9f1', '', '', '', '0', '', '', 'left', '0', '0', 'left', '');


#
# TABLE STRUCTURE FOR: custom_quotation_requests
#

DROP TABLE IF EXISTS custom_quotation_requests;

CREATE TABLE `custom_quotation_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form` longtext,
  `custom_quotation_id` int(11) unsigned NOT NULL,
  `date` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: custom_quotations
#

DROP TABLE IF EXISTS custom_quotations;

CREATE TABLE `custom_quotations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '',
  `formcontent` longtext,
  `inactive` tinyint(4) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `created` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: events
#

DROP TABLE IF EXISTS events;

CREATE TABLE `events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT '',
  `description` text,
  `allday` varchar(30) DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `classname` varchar(255) DEFAULT '',
  `start` varchar(255) DEFAULT '',
  `end` varchar(255) DEFAULT '',
  `user_id` bigint(20) DEFAULT '0',
  `access` varchar(255) DEFAULT '',
  `reminder` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS expenses;

CREATE TABLE `expenses` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(250) DEFAULT '',
  `type` varchar(250) DEFAULT '',
  `category` varchar(250) DEFAULT '',
  `date` varchar(250) DEFAULT '',
  `currency` varchar(250) DEFAULT '',
  `value` float(20,2) DEFAULT '0.00',
  `vat` varchar(250) DEFAULT '',
  `reference` varchar(250) DEFAULT '',
  `project_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rebill` int(20) unsigned NOT NULL DEFAULT '0',
  `invoice_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attachment` varchar(250) DEFAULT '',
  `attachment_description` varchar(250) DEFAULT '',
  `recurring` varchar(250) DEFAULT '',
  `recurring_until` varchar(250) DEFAULT '',
  `user_id` int(20) DEFAULT '0',
  `expense_id` bigint(20) DEFAULT '0',
  `next_payment` varchar(255) DEFAULT '',
  `status` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: invoice_has_items
#

DROP TABLE IF EXISTS invoice_has_items;

CREATE TABLE `invoice_has_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `amount` char(11) DEFAULT NULL,
  `description` text,
  `value` float DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  `task_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: invoice_has_payments
#

DROP TABLE IF EXISTS invoice_has_payments;

CREATE TABLE `invoice_has_payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint(20) DEFAULT '0',
  `reference` varchar(250) DEFAULT '',
  `amount` float DEFAULT '0',
  `date` varchar(20) DEFAULT '',
  `type` varchar(250) DEFAULT '',
  `notes` text,
  `user_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: invoices
#

DROP TABLE IF EXISTS invoices;

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `issue_date` varchar(20) DEFAULT NULL,
  `due_date` varchar(20) DEFAULT NULL,
  `sent_date` varchar(20) DEFAULT NULL,
  `paid_date` varchar(20) DEFAULT NULL,
  `terms` mediumtext,
  `discount` varchar(50) DEFAULT '0',
  `subscription_id` varchar(50) DEFAULT '0',
  `project_id` int(11) DEFAULT '0',
  `tax` varchar(255) DEFAULT '',
  `estimate` int(11) DEFAULT '0',
  `estimate_status` varchar(255) DEFAULT '0',
  `estimate_accepted_date` varchar(255) DEFAULT '0',
  `estimate_sent` varchar(255) DEFAULT '0',
  `sum` float DEFAULT '0',
  `second_tax` varchar(5) DEFAULT '',
  `estimate_reference` varchar(255) DEFAULT '',
  `paid` float DEFAULT NULL,
  `outstanding` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: items
#

DROP TABLE IF EXISTS items;

CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `value` float DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS messages;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `media_id` int(11) DEFAULT '0',
  `from` varchar(120) DEFAULT NULL,
  `text` text,
  `datetime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS migrations;

CREATE TABLE `migrations` (
  `version` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `link` varchar(250) DEFAULT '0',
  `type` varchar(250) DEFAULT '0',
  `icon` varchar(150) DEFAULT NULL,
  `sort` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('1', 'Dashboard', 'dashboard', 'main', 'fa-dashboard', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('2', 'Messages', 'messages', 'main', 'fa-inbox', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('3', 'Projects', 'projects', 'main', 'fa-lightbulb-o', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('4', 'Clients', 'clients', 'main', 'fa-users', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('5', 'Invoices', 'invoices', 'main', 'fa-file-text-o', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('6', 'Items', 'items', 'main', 'fa-archive', '7');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('7', 'Quotations', 'quotations', 'main', 'fa-file-text-o', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('8', 'Subscriptions', 'subscriptions', 'main', 'fa-calendar', '6');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('9', 'Settings', 'settings', 'main', 'fa-cog', '20');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('10', 'QuickAccess', 'quickaccess', 'widget', NULL, '50');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('11', 'User Online', 'useronline', 'widget', NULL, '51');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('12', 'Projects', 'cprojects', 'client', 'fa-lightbulb-o', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('13', 'Invoices', 'cinvoices', 'client', 'fa-file-text-o', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('14', 'Messages', 'cmessages', 'client', 'fa-inbox', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('15', 'Subscriptions', 'csubscriptions', 'client', 'fa-calendar', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('16', 'Tickets', 'tickets', 'main', 'fa-tag', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('17', 'Tickets', 'ctickets', 'client', 'fa-tag', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('18', 'Estimates', 'estimates', 'main', 'fa-files-o', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('19', 'Expenses', 'expenses', 'main', 'fa-money', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('20', 'Calendar', 'calendar', 'main', 'fa-calendar', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('33', 'Reports', 'reports', 'main', 'fa-area-chart', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('107', 'Estimates', 'cestimates', 'client', 'fa-files-o', '3');


#
# TABLE STRUCTURE FOR: privatemessages
#

DROP TABLE IF EXISTS privatemessages;

CREATE TABLE `privatemessages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(150) NOT NULL,
  `sender` varchar(250) NOT NULL,
  `recipient` varchar(250) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text,
  `time` varchar(100) NOT NULL,
  `conversation` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT '0',
  `attachment` varchar(255) DEFAULT '',
  `attachment_link` varchar(255) DEFAULT '',
  `receiver_delete` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_activities
#

DROP TABLE IF EXISTS project_has_activities;

CREATE TABLE `project_has_activities` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) DEFAULT '0',
  `user_id` bigint(20) DEFAULT '0',
  `client_id` bigint(20) DEFAULT '0',
  `datetime` varchar(250) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `message` longtext,
  `type` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_files
#

DROP TABLE IF EXISTS project_has_files;

CREATE TABLE `project_has_files` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `client_id` int(10) DEFAULT '0',
  `type` varchar(80) DEFAULT '0',
  `name` varchar(120) DEFAULT '0',
  `filename` varchar(150) DEFAULT '0',
  `description` text,
  `savename` varchar(200) DEFAULT '0',
  `phase` varchar(100) DEFAULT '0',
  `date` varchar(50) DEFAULT '0',
  `download_counter` int(10) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_invoices
#

DROP TABLE IF EXISTS project_has_invoices;

CREATE TABLE `project_has_invoices` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) DEFAULT '0',
  `invoice_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_milestones
#

DROP TABLE IF EXISTS project_has_milestones;

CREATE TABLE `project_has_milestones` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` longtext,
  `due_date` varchar(255) DEFAULT '',
  `orderindex` int(11) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_tasks
#

DROP TABLE IF EXISTS project_has_tasks;

CREATE TABLE `project_has_tasks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT '0',
  `name` varchar(250) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `status` varchar(50) DEFAULT '0',
  `public` int(10) DEFAULT '0',
  `datetime` int(11) DEFAULT NULL,
  `due_date` varchar(250) DEFAULT NULL,
  `description` text,
  `value` float NOT NULL DEFAULT '0',
  `priority` smallint(6) DEFAULT '0',
  `time` int(11) DEFAULT '0',
  `client_id` int(30) DEFAULT NULL,
  `created_by_client` int(30) DEFAULT '0',
  `tracking` int(11) DEFAULT NULL,
  `time_spent` int(11) DEFAULT NULL,
  `milestone_id` int(11) DEFAULT '0',
  `invoice_id` int(60) DEFAULT NULL,
  `milestone_order` int(11) DEFAULT NULL,
  `task_order` int(11) DEFAULT NULL,
  `progress` int(11) DEFAULT '0',
  `created_at` varchar(50) DEFAULT NULL,
  `start_date` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_timesheets
#

DROP TABLE IF EXISTS project_has_timesheets;

CREATE TABLE `project_has_timesheets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `time` varchar(250) DEFAULT '0',
  `task_id` int(11) DEFAULT '0',
  `client_id` int(11) DEFAULT '0',
  `start` varchar(250) DEFAULT '0',
  `end` varchar(250) DEFAULT '0',
  `invoice_id` int(11) DEFAULT '0',
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_workers
#

DROP TABLE IF EXISTS project_has_workers;

CREATE TABLE `project_has_workers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: projects
#

DROP TABLE IF EXISTS projects;

CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) DEFAULT NULL,
  `name` varchar(65) DEFAULT NULL,
  `description` text,
  `start` varchar(20) DEFAULT NULL,
  `end` varchar(20) DEFAULT NULL,
  `progress` decimal(3,0) DEFAULT NULL,
  `phases` varchar(150) DEFAULT NULL,
  `tracking` int(11) DEFAULT NULL,
  `time_spent` int(11) DEFAULT NULL,
  `datetime` int(11) DEFAULT NULL,
  `sticky` enum('1','0') DEFAULT '0',
  `category` varchar(150) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `note` longtext,
  `progress_calc` tinyint(4) DEFAULT '0',
  `hide_tasks` int(1) DEFAULT '0',
  `enable_client_tasks` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_projects_clients1` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: pw_reset
#

DROP TABLE IF EXISTS pw_reset;

CREATE TABLE `pw_reset` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) DEFAULT '0',
  `timestamp` varchar(250) DEFAULT '0',
  `token` varchar(250) DEFAULT '0',
  `user` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: queues
#

DROP TABLE IF EXISTS queues;

CREATE TABLE `queues` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `description` varchar(250) DEFAULT '0',
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Service', 'First service queue', '0');
INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('2', 'Second Level', 'Second Level Queue', '0');


#
# TABLE STRUCTURE FOR: quotations
#

DROP TABLE IF EXISTS quotations;

CREATE TABLE `quotations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `q1` varchar(50) DEFAULT NULL,
  `q2` varchar(50) DEFAULT NULL,
  `q3` varchar(50) DEFAULT NULL,
  `q4` varchar(150) DEFAULT NULL,
  `q5` text,
  `q6` varchar(50) DEFAULT NULL,
  `company` varchar(150) DEFAULT '-',
  `fullname` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(150) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `city` varchar(150) DEFAULT NULL,
  `zip` varchar(150) DEFAULT NULL,
  `country` varchar(150) DEFAULT NULL,
  `comment` text,
  `date` varchar(50) DEFAULT NULL,
  `status` varchar(150) DEFAULT '0',
  `user_id` int(50) DEFAULT '0',
  `replied` varchar(50) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: subscription_has_items
#

DROP TABLE IF EXISTS subscription_has_items;

CREATE TABLE `subscription_has_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `subscription_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `amount` char(11) DEFAULT NULL,
  `description` text,
  `value` float DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: subscriptions
#

DROP TABLE IF EXISTS subscriptions;

CREATE TABLE `subscriptions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) DEFAULT NULL,
  `company_id` int(10) DEFAULT '0',
  `status` varchar(50) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `issue_date` varchar(20) DEFAULT NULL,
  `end_date` varchar(20) DEFAULT NULL,
  `frequency` varchar(20) DEFAULT NULL,
  `next_payment` varchar(20) DEFAULT NULL,
  `terms` mediumtext,
  `discount` varchar(50) DEFAULT '0',
  `subscribed` varchar(50) DEFAULT '0',
  `tax` varchar(255) DEFAULT '',
  `second_tax` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: task_has_comments
#

DROP TABLE IF EXISTS task_has_comments;

CREATE TABLE `task_has_comments` (
  `id` bigint(255) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `message` text,
  `datetime` varchar(20) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `task_id` bigint(20) DEFAULT NULL,
  `attachment_link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: templates
#

DROP TABLE IF EXISTS templates;

CREATE TABLE `templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `text` text,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ticket_has_articles
#

DROP TABLE IF EXISTS ticket_has_articles;

CREATE TABLE `ticket_has_articles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT NULL,
  `from` varchar(250) NOT NULL DEFAULT '0',
  `reply_to` varchar(250) DEFAULT '0',
  `to` varchar(250) DEFAULT '0',
  `cc` varchar(250) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `message` text,
  `datetime` varchar(250) DEFAULT NULL,
  `internal` int(10) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ticket_has_attachments
#

DROP TABLE IF EXISTS ticket_has_attachments;

CREATE TABLE `ticket_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) DEFAULT '0',
  `filename` varchar(250) DEFAULT '0',
  `savename` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: tickets
#

DROP TABLE IF EXISTS tickets;

CREATE TABLE `tickets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `from` varchar(250) DEFAULT '0',
  `reference` varchar(250) DEFAULT '0',
  `type_id` smallint(6) DEFAULT '1',
  `lock` smallint(6) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `text` text,
  `status` varchar(50) DEFAULT '0',
  `client_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `escalation_time` int(11) DEFAULT '0',
  `priority` varchar(50) DEFAULT '0',
  `created` int(11) DEFAULT '0',
  `queue_id` int(11) DEFAULT '0',
  `updated` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: types
#

DROP TABLE IF EXISTS types;

CREATE TABLE `types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `description` varchar(250) DEFAULT '0',
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO types (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Service Request', 'Service Requests', '0');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `firstname` varchar(120) DEFAULT NULL,
  `lastname` varchar(120) DEFAULT NULL,
  `hashed_password` varchar(128) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `status` enum('active','inactive','deleted') DEFAULT NULL,
  `admin` enum('0','1') DEFAULT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `userpic` varchar(250) DEFAULT 'no-pic.png',
  `title` varchar(150) DEFAULT NULL,
  `access` varchar(150) NOT NULL DEFAULT '1,2',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  `queue` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('9', 'Admin', 'John', 'Doe', '785ea3511702420413df674029fe58d69692b3a0a571c0ba30177c7808db69ea22a8596b1cc5777403d4374dafaa708445a9926d6ead9a262e37cb0d78db1fe5', 'local@localhost', 'active', '1', '2016-02-01 00:00:00', 'no-pic.png', 'Administrator', '1,2,3,4,5,8,6,7,9,10,11,16,18,19,20,33', '1508167065', '1508166994', '0');


