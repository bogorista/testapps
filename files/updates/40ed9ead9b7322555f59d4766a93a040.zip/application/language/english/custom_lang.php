<?php 
/* Add your custom language lines here! You can also overwrite existing language lines. */ 
$lang['application_zip_code'] = "Zip code";
